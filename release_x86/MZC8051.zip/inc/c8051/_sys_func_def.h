#ifndef _SYS_FUNC_DEF_H
#define _SYS_FUNC_DEF_H



///http://www.jhauser.us/arithmetic/SoftFloat.html
/// softfloat 软件浮点数的实现
///
///
///

///乘法 byte2xbyte2
/// 乘数： R4 R5
/// 被乘数: R6 R7
/// 结果： R6 R7
/// (R4 + R5*256) * (R6 + R7*256)
/// =R4 * R6 + R5*R6*256 + R4*R7*256  (+ R5*R7*256*256 此部分忽略,因为结果为byte2)
///
///
///
int  _sys_imul_byte2(int a, int b)   __regparams__  "R6,R7;R4,r5;R6,R7;"
{
	/// MUL AB;
	/// 结果在A，余数在B.
	/// B---0xF0

	_inline_asm_(   """
			  MOV      A,R6;
              MOV      0xF0,R4;
              MUL      AB;
              MOV      R0,0xF0;
              XCH      A,R6;
              MOV      0xF0,R5;
              MUL      AB;
              ADD      A,R0;
              XCH      A,R7;
              MOV      0xF0,R4;
              MUL      AB;
              ADD      A,R7;
              MOV      R7,A;
              RET;
	""");	
}



/// http://www.8052mcu.com/div16
///
int _sys_udiv_byte2(unsigned int a, unsigned int b)  __regparams__  "R6,R7;R6,R7;R4,r5;"
{
    /// R6R7/R4R5
    /// 结果在R7R6中，余数在R5R4中

    _inline_asm_("""

                 /// R7R6 / R5R4
                 CJNE     R5,#0x00,_UIDIV_C_0047
                 CJNE     R7,#0x00,_UIDIV_C_0068
                 MOV      A,R6
                 MOV      0xF0,R4
                 DIV      AB
                 MOV      R6,A
                 MOV      R4,0xF0
                 RET
                 _UIDIV_C_0047:
                 CLR      A
                  XCH      A,R5
                  MOV      R0,A
                  MOV      0xF0,#0x08
                 _UIDIV_C_004D:      MOV      A,R6
                 ADD      A,R6
                 MOV      R6,A
                 MOV      A,R7
                 RLC      A
                 MOV      R7,A
                 MOV      A,R5
                 RLC      A
                 MOV      R5,A
                 MOV      A,R7
                 SUBB     A,R4
                 MOV      A,R5
                 SUBB     A,R0
                 JC       _UIDIV_C_0061
                 MOV      R5,A
                 MOV      A,R7
                 SUBB     A,R4
                 MOV      R7,A
                 INC      R6
                 _UIDIV_C_0061:
                 DJNZ     0xF0,_UIDIV_C_004D
                   CLR      A
                   XCH      A,R7
                   MOV      R4,A
                   RET
                 _UIDIV_C_0068:      MOV      A,R4
                 MOV      R0,A
                 MOV      0xF0,A
                 MOV      A,R7
                 DIV      AB
                 JB       0xD0.2,_UIDIV_C_008D
                 MOV      R7,A
                 MOV      R4,0xF0
                 MOV      0xF0,#0x08
                 _UIDIV_C_0077:      MOV      A,R6
                  ADD      A,R6
                  MOV      R6,A
                  MOV      A,R4
                  RLC      A
                  MOV      R4,A
                  JC       _UIDIV_C_0086
                  SUBB     A,R0
                  JNC      _UIDIV_C_0088
                  DJNZ     0xF0,_UIDIV_C_0077
                  RET
                 _UIDIV_C_0086:      CLR      C
                       SUBB     A,R0
                 _UIDIV_C_0088:      MOV      R4,A
                   INC      R6
                   DJNZ     0xF0,_UIDIV_C_0077
                 _UIDIV_C_008D:      RET

                 """
                );
}

int _sys_umod_byte2(unsigned int a, unsigned int b)  __regparams__  "R4,R5;R6,R7;R4,r5;"
{
    _sys_udiv_byte2(a, b);
    _inline_asm_("RET\n");
}


int _sys_idiv_byte2(int a, int b)    __regparams__  "R6,R7;R6,R7;R4,r5;"
{
    /// R6R7/R4R5
    /// 结果在R7R6中，余数在R5R4中

    _inline_asm_("""
                 CLR      0xD0.5 ;// user bit. 0-- positive. 1--negative
                 MOV      A,R5
                 JNB      0xE0.7,_IDIV_B2_C_0012 ;jump if not negative
                 CPL      0xD0.5
                 CLR      A
                 CLR      C
                 SUBB     A,R4
                 MOV      R4,A
                 CLR      A
                 SUBB     A,R5
                 MOV      R5,A
                 _IDIV_B2_C_0012:
                 MOV      A,R7
                 JNB      0xE0.7,_IDIV_B2_C_002B ;jump if not negative
                 CPL      0xD0.5
                 CLR      A
                 CLR      C
                 SUBB     A,R6
                 MOV      R6,A
                 CLR      A
                 SUBB     A,R7
                 MOV      R7,A"""
                 );

     _sys_udiv_byte2(a, b);

    _inline_asm_("""
                 CLR      C
                 CLR      A
                 SUBB     A,R4
                 MOV      R4,A
                 CLR      A
                 SUBB     A,R5
                 MOV      R5,A
                 SJMP     _IDIV_B2_C_002E
                 _IDIV_B2_C_002B:
                 """
                 );
     _sys_udiv_byte2(a, b);
     _inline_asm_("""
                 _IDIV_B2_C_002E:
                  JNB      0xD0.5,_IDIV_B2_C_0038 ;// jump is positive
                 CLR      C
                 CLR      A
                 SUBB     A,R6
                 MOV      R6,A
                 CLR      A
                 SUBB     A,R7
                 MOV      R7,A
                 _IDIV_B2_C_0038:
                 RET
                 """
                );

}

int _sys_imod_byte2(int a, int b)    __regparams__  "R4,R5;R6,R7;R4,r5;"
{
    _sys_idiv_byte2(a, b);
    _inline_asm_("RET\n");
}





unsigned long _sys_uldiv_byte4(unsigned long a, unsigned long b)  __regparams__  "R4,R5,R6,R7;R4,R5,R6,R7;R0,R1,R2,R3;"
{
    _inline_asm_("""

                 SJMP _C_ULDIV;

                 _ULDIV_LB_C_0003:
                        MOV      0xF0,#0x08
                        MOV      0x82,#0x00
                 _ULDIV_LB_C_0009:
                  MOV      A,R4
                  ADD      A,R4
                  MOV      R4,A
                  MOV      A,R5
                  RLC      A
                  MOV      R5,A
                  XCH      A,R6
                  RLC      A
                  XCH      A,R6
                  XCH      A,R7
                  RLC      A
                  XCH      A,R7
                  XCH      A,0x82
                  RLC      A
                  XCH      A,0x82
                  SUBB     A,R0
                  MOV      A,R6
                  SUBB     A,R1
                  MOV      A,R7
                  SUBB     A,R2
                  MOV      A,0x82
                  SUBB     A,R3
                  JC       _ULDIV_LB_C_0030
                  MOV      0x82,A
                  MOV      A,R5
                  SUBB     A,R0
                  MOV      R5,A
                  MOV      A,R6
                  SUBB     A,R1
                  MOV      R6,A
                  MOV      A,R7
                  SUBB     A,R2
                  MOV      R7,A
                  INC      R4
                 _ULDIV_LB_C_0030:       DJNZ     0xF0,_ULDIV_LB_C_0009
                    CLR      A
                    XCH      A,R5
                    MOV      R0,A
                    CLR      A
                    XCH      A,R6
                    MOV      R1,A
                    CLR      A
                    XCH      A,R7
                    MOV      R2,A
                    MOV      R3,0x82
                    RET
                  _C_ULDIV:
                    CJNE     R3,#0x00,_ULDIV_LB_C_0003
                    CJNE     R2,#0x00,_ULDIV_LB_C_009E
                    CJNE     R1,#0x00,_ULDIV_LB_C_0075
                    MOV      A,R7
                    MOV      0xF0,R0
                    DIV      AB
                    XCH      A,R4
                    XCH      A,R5
                    XCH      A,R6
                    MOV      R7,A
                    MOV      A,0xF0
                    XCH      A,R0
                    MOV      R2,A
                    MOV      R3,#0x18
                 _ULDIV_LB_C_0056:       MOV      A,R4
                  ADD      A,R4
                  MOV      R4,A
                  MOV      A,R5
                  RLC      A
                  MOV      R5,A
                  MOV      A,R6
                  RLC      A
                  MOV      R6,A
                  MOV      A,R7
                  RLC      A
                  MOV      R7,A
                  MOV      A,R0
                  RLC      A
                  MOV      R0,A
                  JBC      0xD0.7,_ULDIV_LB_C_006B
                  SUBB     A,R2
                  JC       _ULDIV_LB_C_006F
                 _ULDIV_LB_C_006B:       MOV      A,R0
                   SUBB     A,R2
                   MOV      R0,A
                   INC      R4
_ULDIV_LB_C_006F:
                   DJNZ     R3,_ULDIV_LB_C_0056
                   CLR      A
                   MOV      R2,A
                   MOV      R1,A
                   RET
                 _ULDIV_LB_C_0075:       MOV      R3,#0x18
                 _ULDIV_LB_C_0077:       MOV      A,R4
                  ADD      A,R4
                  MOV      R4,A
                  MOV      A,R5
                  RLC      A
                  MOV      R5,A
                  MOV      A,R6
                  RLC      A
                  MOV      R6,A
                  MOV      A,R7
                  RLC      A
                  MOV      R7,A
                  XCH      A,R2
                  RLC      A
                  XCH      A,R2
                  JBC      0xD0.7,_ULDIV_LB_C_008E
                  SUBB     A,R0
                  MOV      A,R2
                  SUBB     A,R1
                  JC       _ULDIV_LB_C_0095
                 _ULDIV_LB_C_008E:       MOV      A,R7
                     SUBB     A,R0
                     MOV      R7,A
                     MOV      A,R2
                     SUBB     A,R1
                     MOV      R2,A
                     INC      R4
                 _ULDIV_LB_C_0095:       DJNZ     R3,_ULDIV_LB_C_0077
                    CLR      A
                    XCH      A,R2
                    MOV      R1,A
                    CLR      A
                    XCH      A,R7
                    MOV      R0,A
                    RET
                 _ULDIV_LB_C_009E:       MOV      0xF0,#0x10
                 _ULDIV_LB_C_00A1:       MOV      A,R4
                   ADD      A,R4
                   MOV      R4,A
                   MOV      A,R5
                   RLC      A
                   MOV      R5,A
                   MOV      A,R6
                   RLC      A
                   MOV      R6,A
                   XCH      A,R7
                   RLC      A
                   XCH      A,R7
                   XCH      A,R3
                   RLC      A
                   XCH      A,R3
                   JBC      0xD0.7,_ULDIV_LB_C_00BA
                   SUBB     A,R0
                   MOV      A,R7
                   SUBB     A,R1
                   MOV      A,R3
                   SUBB     A,R2
                   JC       _ULDIV_LB_C_00C4
                 _ULDIV_LB_C_00BA:
                 MOV      A,R6
                    SUBB     A,R0
                    MOV      R6,A
                    MOV      A,R7
                    SUBB     A,R1
                    MOV      R7,A
                    MOV      A,R3
                    SUBB     A,R2
                    MOV      R3,A
                    INC      R4
                 _ULDIV_LB_C_00C4:
                 DJNZ     0xF0,_ULDIV_LB_C_00A1
                  CLR      A
                  XCH      A,R6
                  MOV      R0,A
                  CLR      A
                  XCH      A,R7
                  MOV      R1,A
                  CLR      A
                  XCH      A,R3
                  MOV      R2,A
                  RET

                 """
                );
}


unsigned long _sys_ulmod_byte4(unsigned long a, unsigned long b)  __regparams__  "R0,R1,R2,R3;R4,R5,R6,R7;R0,R1,R2,R3;"
{
    _sys_uldiv_byte4(a, b);
    _inline_asm_("RET\n");
}
long _sys_ldiv_byte4(unsigned long a, unsigned long b)  __regparams__  "R4,R5,R6,R7;R4,R5,R6,R7;R0,R1,R2,R3;"
{
    _inline_asm_("""
                    CLR 0xD0.5;
                    MOV A, R3;
                    JNB 0xE0.7, _LDIV_C00E6;
                    CPL 0xD0.5;

                    CLR A;
                    CLR C;
                    SUBB A, R0;
                    MOV R0, A;
                    CLR A;
                    SUBB A, R1;
                    MOV R1, A;
                    CLR A;
                    SUBB A, R2;
                    MOV R2, A;
                    CLR A;
                    SUBB A, R3;
                    MOV R3, A;

                    _LDIV_C00E6:
                    MOV A, R7;
                    JNB 0xE0.7, _LDIV_C0101;
                    CPL 0xD0.5;
                    LCALL _LDIV_C_0107;
                 """
                );
   _sys_uldiv_byte4(a, b);


   _inline_asm_("""

CLR A;
CLR C;
SUBB A, R0;
MOV R0, A;
CLR A;
SUBB A, R1;
MOV R1, A;
CLR A;
SUBB A, R2;
MOV R2, A;
CLR A;
SUBB A, R3;
MOV R3, A;

SJMP _LDIV_C_0104;
_LDIV_C0101:
                """
               );

_sys_uldiv_byte4(a, b);

_inline_asm_("""

_LDIV_C_0104:
    JNB 0xD0.5, _LDIV_C0114;
_LDIV_C_0107:

        CLR A;
        CLR C;
        SUBB A, R4;
        MOV R4, A;
        CLR A;
        SUBB A, R5;
        MOV R5, A;
        CLR A;
        SUBB A, R6;
        MOV R6, A;
        CLR A;
        SUBB A, R7;
        MOV R7, A;
_LDIV_C0114:
        RET;
             """
            );

}

long _sys_lmod_byte4(unsigned long a, unsigned long b)  __regparams__  "R0,R1,R2,R3;R4,R5,R6,R7;R0,R1,R2,R3;"
{
    _sys_ldiv_byte4(a, b);
    _inline_asm_("RET\n");

}

///乘法 byte4xbyte4
/// 乘数： r0 r1 r2 r3
/// 被乘数: r4 r5 r6 r7
/// 结果： r4 r5 r6 r7
/// (r0-0 r1-1 r2-2 r3-3) * (r4-0 r5-1 r6-2 r7-3)
/// = r0r4-0 r0r5-1 r0r6-2 r0r7-3
/// + r1r4-1 r1r5-2 r1r6-3 r1r7-4
/// + r2r4-2 r2r5-3 r2r6-4 r2r7-5
/// + r3r4-3 r3r5-4 r3r6-5 r3r7-6
/// 其中左右大于等于4byte的都去掉，剩余：
/// = r0r4-0 r0r5-1 r0r6-2 r0r7-3
/// + r1r4-1 r1r5-2 r1r6-3
/// + r2r4-2 r2r5-3
/// + r3r4-3
///
long _sys_lmul_byte4(long a, long b) __regparams__ "R4,R5,R6,R7;R0,R1,R2,R3;R4,R5,R6,R7;"
{
	_inline_asm_("""
			MOV      A,R3; 
            MOV      0xF0,R4; 
            MUL      AB; 
            XCH      A,R7; 
            MOV      0xF0,R0; 
            MUL      AB; 
            ADD      A,R7; 
            MOV      R7,A; 
            MOV      A,R2; 
            MOV      0xF0,R5; 
            MUL      AB; 
            ADD      A,R7; 
            MOV      R7,A; 
            MOV      0xF0,R1; 
            MOV      A,R6; 
            MUL      AB; 
            ADD      A,R7; 
            MOV      R7,A; 
            MOV      A,R1; 
            MOV      0xF0,R5; 
            MUL      AB; 
            XCH      A,R6; 
            MOV      R3,0xF0; 
            MOV      0xF0,R0; 
            MUL      AB; 
            ADD      A,R6;
            XCH      A,R7;
            ADDC     A,R3;
            ADD      A,0xF0;
            MOV      R6,A;
            MOV      A,R2;
            MOV      0xF0,R4;
            MUL      AB;
            ADD      A,R7;
            XCH      A,R6;
            ADDC     A,0xF0;
            MOV      R7,A;
            MOV      A,R0;
            MOV      0xF0,R5;
            MUL      AB;
            MOV      R5,A;
            MOV      R2,0xF0;
            MOV      A,R0;
            MOV      0xF0,R4;
            MUL      AB;
            XCH      A,R4;
            XCH      A,0xF0;
            ADD      A,R5;
            XCH      A,R6;
            ADDC     A,R2;
            MOV      R5,A;
            CLR      A;
            ADDC     A,R7;
            MOV      R7,A;
            MOV      A,R1;
            MUL      AB;
            ADD      A,R6;
            XCH      A,R5;
            ADDC     A,0xF0;
            MOV      R6,A;
            CLR      A;
            ADDC     A,R7;
            MOV      R7,A;
            RET;
			""");
			

}

///
/// 将整数转为float类型
/// 整数保存在R4R5R6R7中
/// 结果float保存在R4R5R6R7中
float _sys_fcast(long a) __regparams__ "R4,R5,R6,R7;R4,R5,R6,R7;"
{
    //R7 R6 R5 R4

    _inline_asm_("""

C_FCASTL:
                        MOV      0xF0,#0x20
                        MOV A, R7;
                       RLC      A
                       MOV      0D0H.5, C
                       JNB      0D0H.5, _FCAST_C_001F
                       LCALL    _FCAST_C_LNEG
                 _FCAST_C_001F:       MOV      A,R7
                       RLC      A
                       JC       _FCAST_C_0033
                       MOV      A,R4
                       RLC      A
                       MOV      R4,A
                       MOV      A,R5
                       RLC      A
                       MOV      R5,A
                       MOV      A,R6
                       RLC      A
                       MOV      R6,A
                       MOV      A,R7
                       RLC      A
                       MOV      R7,A
                       DJNZ     0xF0,_FCAST_C_001F;//B(
                       RET
                 _FCAST_C_0033:      MOV      A,0xF0;B(
                       ADD      A,#0x7E
                       MOV      C,0xD0.5;//F0(
                       RRC      A
                       XCH      A,R7
                       MOV      0xE0.7,C
                       XCH      A,R6
                       XCH      A,R5
                       MOV      R4,A
                       RET
                 _FCAST_C_LNEG:
                       CLR      C
                       CLR      A
                       SUBB     A,R4
                       MOV      R4,A
                       CLR      A
                       SUBB     A,R5
                       MOV      R5,A
                       CLR      A
                       SUBB     A,R6
                       MOV      R6,A
                       CLR      A
                       SUBB     A,R7
                       MOV      R7,A
                       RET

                 """
                );


}

#if 0
float _sys_fpsub(float a, float b) __regparams__ "R4,R5,R6,R7;R4,R5,R6,R7;R0,R1,R2,R3;"
{
    //R7R6R5R4 +/- R3R2R1R0

    _inline_asm_("""
                 MOV A, R3;
                 XRL A, #0x80;// XOR 最高位取反，其他位不变
                 MOV R3, A;
                 """);
       //_sys_fpadd();
}
#endif


int _sys_castf(float a) __regparams__ "R4,R5,R6,R7;R4,R5,R6,R7;"
{
    /// R7R6R5R4
    _inline_asm_(
                """
                C_CASTF:
                 MOV      A,R6
                 SETB     0xE0.7
                 XCH      A,R6
                 RLC      A
                 MOV      A,R7
                 RLC      A
                 MOV      0xD0.5,C
                 ADD      A,#0x81
                 JC       _CASTF_C_0016
                 CLR      A
                _CASTF_C_0011:
                     MOV      R4,A
                 MOV      R5,A
                 MOV      R6,A
                 MOV      R7,A
                _CASTF_C_0015:
                RET
                _CASTF_C_0016:
                MOV      R7,A
                 CLR      A
                 XCH      A,R4
                 XCH      A,R5
                 XCH      A,R6
                 XCH      A,R7
                 ADD      A,#0xE0
                 JNC      _CASTF_C_0031
                 MOV      A,#0xFF
                 SJMP     _CASTF_C_0011
                _CASTF_C_0024:
                CLR      C
                 XCH      A,R7
                 RRC      A
                 XCH      A,R7
                 XCH      A,R6
                 RRC      A
                 XCH      A,R6
                 XCH      A,R5
                 RRC      A
                 XCH      A,R5
                 XCH      A,R4
                 RRC      A
                 XCH      A,R4
                _CASTF_C_0031:
                INC      A
                 JNZ      _CASTF_C_0024
                 JNB      0xD0.5,_CASTF_C_0015
                 LJMP     _CASTF_C_003A
                _CASTF_C_003A:
                CLR      C
                CLR      A
                SUBB     A,R4
                MOV      R4,A
                CLR      A
                SUBB     A,R5
                MOV      R5,A
                CLR      A
                SUBB     A,R6
                MOV      R6,A
                CLR      A
                SUBB     A,R7
                MOV      R7,A
                RET
                """
                );
}



float _sys_fpadd(float a, float b) __regparams__ "R4,R5,R6,R7;R4,R5,R6,R7;R0,R1,R2,R3;"
{

    /// R7R6R5R4 +/- R3R2R1R0

///C_FPSUB:
///MOV      A,R3
///XRL      A,#0x80 ;// XOR 最高位取反，其他位不变
///MOV      R3,A
    _inline_asm_("""



                  C_FPADD:
                   MOV      A,R2
                   RLC      A
                   MOV      A,R3
                   RLC      A
                   JZ       _FPADD_C_0021;// expo 指数为0
                   INC      A
                   JZ       _FPADD_C_0003  ;//expo指数为0xff
                   MOV      A,R6
                   RLC      A
                   MOV      A,R7
                   RLC      A
                   JNZ      _FPADD_C_0022 ;//指数不是0
                   MOV      A,R3   ;//指数是0，直接将R3R2R1R0复制到R7R6R5R4
                   MOV      R7,A
                   MOV      A,R2
                   MOV      R6,A
                   MOV      A,R1
                   MOV      R5,A
                   MOV      A,R0
                   MOV      R4,A
      _FPADD_C_0021:       RET
      _FPADD_C_0022: INC      A
                  JZ       _FPADD_C_0003
                  SETB     C
                  MOV      A,R0
                  SUBB     A,R4
                  MOV      A,R1
                  SUBB     A,R5
                  MOV      A,R2
                  SUBB     A,R6
                  MOV      A,R3
                  CLR      0xE0.7 ;//A.7
                  MOV      0xF0,R7;//B
                  CLR      0xF0.7
                  SUBB     A,0xF0
                  JC       _FPADD_C_0043
                  MOV      A,R3
                  XCH      A,R7
                  MOV      R3,A
                  MOV      A,R2
                  XCH      A,R6
                  MOV      R2,A
                  MOV      A,R1
                  XCH      A,R5
                  MOV      R1,A
                  MOV      A,R0
                  XCH      A,R4
                  MOV      R0,A
   _FPADD_C_0043:       LCALL    _FPADD_C_00FB
                    MOV      0xF0,0xD0
                    ANL      A,R3
                    INC      A
                    JNZ      _FPADD_C_0050
                    JB       0xD0.5,_FPADD_C_0003
 _FPADD_C_0050:       MOV      A,R3
                     INC      A
                     JNZ      _FPADD_C_005B
                     JNC      _FPADD_C_0058
                     CPL      0xD0.5
_FPADD_C_0058:
                                      LJMP     _FPADD_C_013A
 _FPADD_C_005B:
                                      MOV      0xD0.5,C
                   MOV      A,R7
                   INC      A
                   JZ       _FPADD_C_0058
                   CLR      A
                   XCH      A,R7
                   PUSH     0xE0
                   CLR      C
                   SUBB     A,R3
                   MOV      R3,A
                   JZ       _FPADD_C_00A5
                   SUBB     A,#0x18
                   JZ       _FPADD_C_0076
                   JC       _FPADD_C_007D
                   POP      0xE0
                   MOV      R0,A
                   LJMP     _FPADD_C_0112
_FPADD_C_0076:                   CLR      A
                   MOV      R0,A
                   MOV      R1,A
                   XCH      A,R2
                   MOV      R7,A
                   SJMP     _FPADD_C_00A5
_FPADD_C_007D:     MOV      A,R3
                   JNB      0xE0.4,_FPADD_C_0087
                   CLR      A
                   XCH      A,R2
                   MOV      R0,A
                   CLR      A
                   XCH      A,R1
                   MOV      R7,A
_FPADD_C_0087:       MOV      A,R3
                     JNB      0xE0.3,_FPADD_C_0090
                     CLR      A
                     XCH      A,R2
                     XCH      A,R1
                     XCH      A,R0
                     MOV      R7,A
_FPADD_C_0090:       MOV      A,R3
                     ANL      A,#0x07
                     JZ       _FPADD_C_00A5
                     MOV      R3,A
_FPADD_C_0096:       CLR      C
                     MOV      A,R2
                     RRC      A
                     MOV      R2,A
                     MOV      A,R1
                     RRC      A
                     MOV      R1,A
                     MOV      A,R0
                     RRC      A
                     MOV      R0,A
                     MOV      A,R7
                     RRC      A
                     MOV      R7,A
                     DJNZ     R3,_FPADD_C_0096
 _FPADD_C_00A5:
                                      JNB      0xF0.5,_FPADD_C_00D7
                    CLR      C
                    CLR      A
                    SUBB     A,R7
                    MOV      R7,A
                    MOV      A,R4
                    SUBB     A,R0
                    MOV      R4,A
                    MOV      A,R5
                    SUBB     A,R1
                    MOV      R5,A
                    MOV      A,R6
                    SUBB     A,R2
                    MOV      R6,A
                    POP      0xE0
                    MOV      R0,A
                    MOV      A,R4
                    ORL      A,R5
                    ORL      A,R6
                    ORL      A,R7
                    JNZ      _FPADD_C_00D0
                    RET
_FPADD_C_00BF:      DJNZ     R0,_FPADD_C_00C4
                    LJMP     _FPADD_C_0137
                 _FPADD_C_00C4:       MOV      A,R7
                     ADD      A,R7
                     MOV      R7,A
                     MOV      A,R4
                     RLC      A
                     MOV      R4,A
                     MOV      A,R5
                     RLC      A
                     MOV      R5,A
                     MOV      A,R6
                     RLC      A
                     MOV      R6,A
                 _FPADD_C_00D0:
                        MOV      A,R6
                      JNB      0xE0.7,_FPADD_C_00BF
                      LJMP     _FPADD_C_0112
                 _FPADD_C_00D7:       MOV      A,R4
                    ADD      A,R0
                    MOV      R4,A
                    MOV      A,R5
                    ADDC     A,R1
                    MOV      R5,A
                    MOV      A,R6
                    ADDC     A,R2
                    MOV      R6,A
                    POP      0xE0
                    MOV      R0,A
                    JNC      _FPADD_C_00F8
                    INC      R0
                    CJNE     R0,#0x00,_FPADD_C_00EC
                    LJMP     _FPADD_C_013A
                 _FPADD_C_00EC:       MOV      A,R6
                     RRC      A
                     MOV      R6,A
                     MOV      A,R5
                     RRC      A
                     MOV      R5,A
                     MOV      A,R4
                     RRC      A
                     MOV      R4,A
                     MOV      A,R7
                     RRC      A
                     MOV      R7,A
_FPADD_C_00F8: LJMP     _FPADD_C_0112
_FPADD_C_00FB:       MOV      A,R2
                    SETB     0xE0.7
                    XCH      A,R2
                    RLC      A
                    MOV      A,R3
                    RLC      A
                    MOV      R3,A
                    MOV      0xD0.5,C
                    MOV      A,R6
                    SETB     0xE0.7
                    XCH      A,R6
                    RLC      A
                    MOV      A,R7
                    RLC      A
                    MOV      R7,A
                    JNC      _FPADD_C_0111
                    CPL      0xD0.5
                 _FPADD_C_0111:
                        RET
                 _FPADD_C_0112:
                        MOV      A,R7
                    JNB      0xE0.7,_FPADD_C_0126
                    INC      R4
                    CJNE     R4,#0x00,_FPADD_C_0126
                    INC      R5
                    CJNE     R5,#0x00,_FPADD_C_0126
                    INC      R6
                    CJNE     R6,#0x00,_FPADD_C_0126
                    INC      R0
                    MOV      A,R0
                    JZ       _FPADD_C_013A
                 _FPADD_C_0126:       MOV      C,0xD0.5
                  MOV      A,R0
                  RRC      A
                  MOV      R7,A
                  MOV      A,R6
                  MOV      0xE0.7,C
                  MOV      R6,A
                  RET
_FPADD_C_0130:         MOV      A,#0xFF
                 _FPADD_C_0132:       MOV      R7,A
                        MOV      R6,A
                 _FPADD_C_0134:       MOV      R5,A
                    MOV      R4,A
                    RET
                 _FPADD_C_0137:       CLR      A
                        SJMP     _FPADD_C_0132
                 _FPADD_C_013A:       MOV      C,0xD0.5
                  MOV      A,#0xFF
                  RRC      A
                  MOV      R7,A
                  MOV      R6,#0x80
                  CLR      A
                  SJMP     _FPADD_C_0134
                 _FPADD_C_0003:
                         LJMP _FPADD_C_0130

                 """);

}

float _sys_fpsub(float a, float b) __regparams__ "R4,R5,R6,R7;R4,R5,R6,R7;R0,R1,R2,R3;"
{
    _inline_asm_("""
                 C_FPSUB:
                 MOV A, R3;
                XRL A, #0x80;
                MOV R3, A;

                 """
                );

    return _sys_fpadd(a, b);
}

float _sys_fpmul(float a, float b) __regparams__ "R4,R5,R6,R7;R4,R5,R6,R7;R0,R1,R2,R3;"
{
    _inline_asm_(
                """
                /// R7R6R5R4 * R3R2R1R0
                         C_FPMUL:
                  MOV      A,R7
                  ORL      A,R6
                  JZ       _FPMUL_C_0018
                  MOV      A,R3
                  ORL      A,R2
                  JNZ      _FPMUL_C_0022
                  MOV      A,R6
                  RLC      A
                  MOV      A,R7
                  RLC      A
                  INC      A
                  JZ       _FPMUL_C_001F
                  CLR      A
                  MOV      R7,A
                  MOV      R4,A
                  MOV      R5,A
                  MOV      R6,A
                _FPMUL_C_0017:       RET
                _FPMUL_C_0018:       MOV      A,R2
                RLC      A
                MOV      A,R3
                RLC      A
                INC      A
                JNZ      _FPMUL_C_0017
                _FPMUL_C_001F:       LJMP     _FPMUL_C_013E
                _FPMUL_C_0022:       LCALL    _FPMUL_C_0109
                ANL      A,R3
                INC      A
                JZ       _FPMUL_C_0032
                CLR      A
                XCH      A,R7
                ADD      A,#0x81
                JNC      _FPMUL_C_0035
                ADD      A,R3
                JNC      _FPMUL_C_003B
                _FPMUL_C_0032:       LJMP     _FPMUL_C_0148
                _FPMUL_C_0035:       ADD      A,R3
                  JC       _FPMUL_C_003B
                  LJMP     _FPMUL_C_0145
                _FPMUL_C_003B:       PUSH     0xE0
                MOV      A,R0
                ORL      A,R1
                JNZ      _FPMUL_C_0085
                CJNE     R2,#0x80,_FPMUL_C_004A
                _FPMUL_C_0044:       POP      0xE0
                MOV      R0,A
                LJMP     _FPMUL_C_0134
                _FPMUL_C_004A:       MOV      A,R4
                ORL      A,R5
                JNZ      _FPMUL_C_006A
                CJNE     R6,#0x80,_FPMUL_C_0059
                _FPMUL_C_0051:                MOV      A,R0
                MOV      R4,A
                MOV      A,R1
                MOV      R5,A
                MOV      A,R2
                MOV      R6,A
                SJMP     _FPMUL_C_0044
                _FPMUL_C_0059:       MOV      A,R2
                MOV      0xF0,R6
                MUL      AB
                MOV      R5,A
                MOV      A,0xF0
                LJMP     _FPMUL_C_00EC
                _FPMUL_C_0063:       MOV      A,R2
                XCH      A,R6
                MOV      R2,A
                MOV      A,R1
                MOV      R5,A
                MOV      A,R0
                MOV      R4,A
                _FPMUL_C_006A:                MOV      A,R4
                MOV      0xF0,R2
                MUL      AB
                MOV      R7,A
                MOV      A,0xF0
                XCH      A,R5
                MOV      0xF0,R2
                MUL      AB
                ADD      A,R5
                MOV      R4,A
                CLR      A
                ADDC     A,0xF0
                XCH      A,R6
                MOV      0xF0,R2
                MUL      AB
                ADD      A,R6
                MOV      R5,A
                CLR      A
                ADDC     A,0xF0
                SJMP     _FPMUL_C_00EC
                _FPMUL_C_0085:     MOV      A,R4
                ORL      A,R5
                JNZ      _FPMUL_C_008E
                CJNE     R6,#0x80,_FPMUL_C_0063
                SJMP     _FPMUL_C_0051
                MOV      A,R4
                _FPMUL_C_008E:         MOV      0xF0,R0
                MUL      AB
                MOV      R7,0xF0
                MOV      A,R5
                MOV      0xF0,R0
                MUL      AB
                ADD      A,R7
                MOV      R7,A
                CLR      A
                ADDC     A,0xF0
                MOV      R3,A
                MOV      A,R4
                MOV      0xF0,R1
                MUL      AB
                ADD      A,R7
                MOV      A,0xF0
                ADDC     A,R3
                MOV      R7,A
                CLR      A
                RLC      A
                XCH      A,R0
                MOV      0xF0,R6
                MUL      AB
                ADD      A,R7
                MOV      R7,A
                MOV      A,0xF0
                ADDC     A,R0
                MOV      R3,A
                MOV      A,R5
                MOV      0xF0,R1
                MUL      AB
                ADD      A,R7
                MOV      R7,A
                MOV      A,0xF0
                ADDC     A,R3
                MOV      R3,A
                CLR      A
                RLC      A
                XCH      A,R4
                MOV      0xF0,R2
                MUL      AB
                ADD      A,R7
                MOV      R7,A
                MOV      A,0xF0
                ADDC     A,R3
                XCH      A,R4
                ADDC     A,#0x00
                XCH      A,R5
                MOV      0xF0,R2
                MUL      AB
                ADD      A,R4
                MOV      R4,A
                MOV      A,0xF0
                ADDC     A,R5
                MOV      R5,A
                CLR      A
                RLC      A
                XCH      A,R2
                MOV      0xF0,R6
                MUL      AB
                ADD      A,R5
                MOV      R5,A
                MOV      A,0xF0
                ADDC     A,R2
                XCH      A,R6
                MOV      0xF0,R1
                MUL      AB
                ADD      A,R4
                MOV      R4,A
                MOV      A,0xF0
                ADDC     A,R5
                MOV      R5,A
                CLR      A
                ADDC     A,R6
                _FPMUL_C_00EC:       MOV      R6,A
                RLC      A
                POP      0xE0
                MOV      R0,A
                JNC      _FPMUL_C_00FA
                INC      R0
                CJNE     R0,#0x00,_FPMUL_C_0106
                LJMP     _FPMUL_C_0148
                _FPMUL_C_00FA:       MOV      A,R7
                ADD      A,R7
                MOV      R7,A
                MOV      A,R4
                RLC      A
                MOV      R4,A
                MOV      A,R5
                RLC      A
                MOV      R5,A
                MOV      A,R6
                RLC      A
                MOV      R6,A
                _FPMUL_C_0106:       LJMP     _FPMUL_C_0120
                _FPMUL_C_0109:       MOV      A,R2
                SETB     0xE0.7
                XCH      A,R2
                RLC      A
                MOV      A,R3
                RLC      A
                MOV      R3,A
                MOV      0xD0.5,C
                MOV      A,R6
                SETB     0xE0.7
                XCH      A,R6
                RLC      A
                MOV      A,R7
                RLC      A
                MOV      R7,A
                JNC      _FPMUL_C_011F
                CPL      0xD0.5
                _FPMUL_C_011F:       RET
                _FPMUL_C_0120:       MOV      A,R7
                JNB      0xE0.7,_FPMUL_C_0134
                INC      R4
                CJNE     R4,#0x00,_FPMUL_C_0134
                INC      R5
                CJNE     R5,#0x00,_FPMUL_C_0134
                INC      R6
                CJNE     R6,#0x00,_FPMUL_C_0134
                INC      R0
                MOV      A,R0
                JZ       _FPMUL_C_0148
                _FPMUL_C_0134:       MOV      C,0xD0.5
                MOV      A,R0
                RRC      A
                MOV      R7,A
                MOV      A,R6
                MOV      0xE0.7,C
                MOV      R6,A
                RET
                _FPMUL_C_013E:       MOV      A,#0xFF
                _FPMUL_C_0140:          MOV      R7,A
                  MOV      R6,A
                _FPMUL_C_0142:       MOV      R5,A
                MOV      R4,A
                RET
                _FPMUL_C_0145: CLR      A
                SJMP     _FPMUL_C_0140
                _FPMUL_C_0148:       MOV      C,0xD0.5
                MOV      A,#0xFF
                RRC      A
                MOV      R7,A
                MOV      R6,#0x80
                CLR      A
                SJMP     _FPMUL_C_0142
                """  );

}

float _sys_fpdiv(float a, float b) __regparams__ "R4,R5,R6,R7;R4,R5,R6,R7;R0,R1,R2,R3;"
{
    /// R7R6R5R4 / R3R2R1R0

    _inline_asm_("""
                 MOV      A,R7
                 ANL      A,R6
                 INC      A
                 JZ       _FPDIV_C_0010
                 MOV      A,R3
                 ANL      A,R2
                 INC      A
                 JNZ      _FPDIV_C_0013
                 _FPDIV_C_0010:       LJMP     _FPDIV_C_00D8
                 _FPDIV_C_0013:       LCALL    _FPDIV_C_00A3
                 ANL      A,R3
                 INC      A
                 JZ       _FPDIV_C_0010
                 MOV      A,R7
                 ORL      A,R3
                 JZ       _FPDIV_C_0010
                 MOV      A,R7
                 JNZ      _FPDIV_C_0025
                 MOV      R6,A
                 MOV      R5,A
                 MOV      R4,A
                 RET
                 _FPDIV_C_0025:       XCH      A,R3
                 JZ       _FPDIV_C_0003
                 ADD      A,#0x81
                 XCH      A,R3
                 JNC      _FPDIV_C_0036
                 CLR      C
                 SUBB     A,R3
                 JZ       _FPDIV_C_0033
                 JNC      _FPDIV_C_0039
                 _FPDIV_C_0033:       LJMP     _FPDIV_C_00DF
                 _FPDIV_C_0036:       SUBB     A,R3
                 JNC      _FPDIV_C_0003
                 _FPDIV_C_0039:       MOV      0x82,A
                 MOV      A,R2
                 ADD      A,R2
                 ORL      A,R0
                 ORL      A,R1
                 JNZ      _FPDIV_C_0046
                 MOV      R0,0x82
                 LJMP     _FPDIV_C_00CE
                 _FPDIV_C_0046:       MOV      0xF0,#0x00
                 MOV      R7,#0x1A
                 MOV      R3,#0x80
                 _FPDIV_C_004D:       CLR      C
                 MOV      A,R4
                 SUBB     A,R0
                 MOV      A,R5
                 SUBB     A,R1
                 MOV      A,R6
                 SUBB     A,R2
                 JC       _FPDIV_C_0063
                 _FPDIV_C_0056:       CLR      C
                 MOV      A,R4
                 SUBB     A,R0
                 MOV      R4,A
                 MOV      A,R5
                 SUBB     A,R1
                 MOV      R5,A
                 MOV      A,R6
                 SUBB     A,R2
                 MOV      R6,A
                 MOV      A,R3
                 ORL      0xF0,A
                 _FPDIV_C_0063:       DJNZ     R7,_FPDIV_C_0088
                 MOV      R7,0xF0
                 POP      0xE0
                 MOV      R4,A
                 POP      0xE0
                 MOV      R5,A
                 POP      0xE0
                 MOV      R6,A
                 MOV      R0,0x82
                 JB       0xE0.7,_FPDIV_C_0085
                 DEC      R0
                 MOV      A,R0
                 JZ       _FPDIV_C_0033
                 MOV      A,R7
                 ADD      A,R7
                 MOV      R7,A
                 MOV      A,R4
                 RLC      A
                 MOV      R4,A
                 MOV      A,R5
                 RLC      A
                 MOV      R5,A
                 MOV      A,R6
                 RLC      A
                 MOV      R6,A
                 _FPDIV_C_0085:       LJMP     _FPDIV_C_00BA
                 _FPDIV_C_0088:       MOV      A,R3
                 RR       A
                 MOV      R3,A
                 JNB      0xE0.7,_FPDIV_C_0093
                 PUSH     0xF0
                 MOV      0xF0,#0x00
                 _FPDIV_C_0093:       MOV      A,R4
                 ADD      A,R4
                 MOV      R4,A
                 MOV      A,R5
                 RLC      A
                 MOV      R5,A
                 MOV      A,R6
                 RLC      A
                 MOV      R6,A
                 JC       _FPDIV_C_0056
                 JNB      0xE0.7,_FPDIV_C_0063
                 SJMP     _FPDIV_C_004D
                 _FPDIV_C_00A3:       MOV      A,R2
                 SETB     0xE0.7
                 XCH      A,R2
                 RLC      A
                 MOV      A,R3
                 RLC      A
                 MOV      R3,A
                 MOV      0xD0.5,C
                 MOV      A,R6
                 SETB     0xE0.7
                 XCH      A,R6
                 RLC      A
                 MOV      A,R7
                 RLC      A
                 MOV      R7,A
                 JNC      _FPDIV_C_00B9
                 CPL      0xD0.5
                 _FPDIV_C_00B9:       RET
                 _FPDIV_C_00BA:       MOV      A,R7
                 JNB      0xE0.7,_FPDIV_C_00CE
                 INC      R4
                 CJNE     R4,#0x00,_FPDIV_C_00CE
                 INC      R5
                 CJNE     R5,#0x00,_FPDIV_C_00CE
                 INC      R6
                 CJNE     R6,#0x00,_FPDIV_C_00CE
                 INC      R0
                 MOV      A,R0
                 JZ       _FPDIV_C_00E2
                 _FPDIV_C_00CE:       MOV      C,0xD0.5
                 MOV      A,R0
                 RRC      A
                 MOV      R7,A
                 MOV      A,R6
                 MOV      0xE0.7,C
                 MOV      R6,A
                 RET
                 _FPDIV_C_00D8:       MOV      A,#0xFF
                 _FPDIV_C_00DA:       MOV      R7,A
                 MOV      R6,A
                 _FPDIV_C_00DC:       MOV      R5,A
                 MOV      R4,A
                 RET
                 _FPDIV_C_00DF:       CLR      A
                 SJMP     _FPDIV_C_00DA
                 _FPDIV_C_00E2:       MOV      C,0xD0.5
                 MOV      A,#0xFF
                 RRC      A
                 MOV      R7,A
                 MOV      R6,#0x80
                 CLR      A
                 SJMP     _FPDIV_C_00DC
                 _FPDIV_C_0003:    LJMP _FPDIV_C_00E2

                 """);

}


long _sys_negative(long a) __regparams__ "R4,R5,R6,R7;R4,R5,R6,R7;"
{
    _inline_asm_("""
                 CLR C;
            CLR A;
            SUBB A, R4;
            MOV R4,A;
            CLR A;
            SUBB A, R5;
            MOV R5, A;
            CLR A;
            SUBB A, R6;
            MOV R6, A;
            CLR A;
            SUBB A, R7;
            MOV R7, A;
            RET
                 """
                );


}






















#endif

