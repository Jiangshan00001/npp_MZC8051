void _sim_assert(char a)  __regparams__ ";A;"
{
	_inline_asm_("SIMTRAP 0, 0;\n");
}
inline void _sim_exit()
{
	_inline_asm_("SIMTRAP 1, 0;\n");
}
